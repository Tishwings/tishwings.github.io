### Date | Place

# Title

## Subtitle

### Author

Description

The code of this boilerplate is at https://github.com/digicademy/impress-js-boilerplate

A live demo can be found at http://digicademy.github.io/impress-js-boilerplate/

Released under [CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/), @digicademy
